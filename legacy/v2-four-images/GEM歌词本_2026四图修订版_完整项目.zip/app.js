(() => {
  'use strict';

  const DATA = window.GEM_LYRICBOOK_DATA;
  if (!DATA || !Array.isArray(DATA.songs)) {
    document.body.innerHTML = '<main style="padding:2rem;font-family:sans-serif">曲目数据加载失败。</main>';
    return;
  }

  const BASE_STORAGE_KEY = 'gem-iam-gloria-lyricbook-v2';
  const LEGACY_STORAGE_KEY = 'gem-iam-gloria-lyricbook-v1';
  const STORAGE_KEY = window.GEM_EMBEDDED_ID ? `${BASE_STORAGE_KEY}:${window.GEM_EMBEDDED_ID}` : BASE_STORAGE_KEY;
  const fontScales = [0.84, 0.92, 1, 1.12, 1.26];
  const sourceShort = { image1: '截图 1', image2: '截图 2', image3: '截图 3', image4: '截图 4', web2026: '2026 现场补充' };
  const songs = DATA.songs.filter((song) => song.title !== '其他');
  const permitOther = DATA.songs.find((song) => song.title === '其他');

  const $ = (selector, root = document) => root.querySelector(selector);
  const $$ = (selector, root = document) => Array.from(root.querySelectorAll(selector));

  const elements = {
    html: document.documentElement,
    search: $('#searchInput'),
    filter: $('#filterSelect'),
    sort: $('#sortSelect'),
    fontRange: $('#fontRange'),
    songList: $('#songList'),
    resultCount: $('#resultCount'),
    sidebar: $('#songSidebar'),
    sidebarToggle: $('#sidebarToggle'),
    sidebarClose: $('#sidebarClose'),
    sidebarBackdrop: $('#sidebarBackdrop'),
    songNumber: $('#songNumber'),
    songTotal: $('#songTotal'),
    songKicker: $('#songKicker'),
    songTitle: $('#songTitle'),
    songAliases: $('#songAliases'),
    songTags: $('#songTags'),
    songNote: $('#songNote'),
    previewTab: $('#previewTab'),
    editTab: $('#editTab'),
    previewPanel: $('#previewPanel'),
    editPanel: $('#editPanel'),
    emptyState: $('#emptyState'),
    lyricPreview: $('#lyricPreview'),
    lyricEditor: $('#lyricEditor'),
    charCount: $('#charCount'),
    saveStatus: $('#saveStatus'),
    favoriteButton: $('#favoriteButton'),
    learnedButton: $('#learnedButton'),
    previousSong: $('#previousSong'),
    nextSong: $('#nextSong'),
    startEditing: $('#startEditing'),
    clearLyrics: $('#clearLyrics'),
    sourcePills: $('#sourcePills'),
    appleLink: $('#appleLink'),
    youtubeLink: $('#youtubeLink'),
    officialLink: $('#officialLink'),
    statSongs: $('#statSongs'),
    statCoverage: $('#statCoverage'),
    statFilled: $('#statFilled'),
    statVerified: $('#statVerified'),
    themeButton: $('#themeButton'),
    focusButton: $('#focusButton'),
    focusOverlay: $('#focusOverlay'),
    exitFocus: $('#exitFocus'),
    focusKicker: $('#focusKicker'),
    focusTitle: $('#focusTitle'),
    focusLyrics: $('#focusLyrics'),
    importFile: $('#importFile'),
    importButton: $('#importButton'),
    pasteImportButton: $('#pasteImportButton'),
    bulkPaste: $('#bulkPaste'),
    importResult: $('#importResult'),
    exportHtml: $('#exportHtml'),
    exportJson: $('#exportJson'),
    exportMarkdown: $('#exportMarkdown'),
    downloadTemplate: $('#downloadTemplate'),
    printBuildButton: $('#printBuildButton'),
    printRoot: $('#printRoot'),
    dynamicPrintStyle: $('#dynamicPrintStyle'),
    printCover: $('#printCover'),
    printToc: $('#printToc'),
    printEmpty: $('#printEmpty'),
    printNotes: $('#printNotes'),
    printEstimate: $('#printEstimate'),
    toastRegion: $('#toastRegion'),
  };

  function defaultState() {
    return {
      selectedId: songs[0]?.id || '',
      lyrics: {},
      favorites: [],
      learned: [],
      theme: 'light',
      fontLevel: 2,
      viewMode: 'preview',
      search: '',
      filter: 'all',
      sort: 'source',
    };
  }

  function normalizeState(parsed, fallback) {
    if (!parsed || typeof parsed !== 'object') return fallback;
    return {
      ...fallback,
      ...parsed,
      lyrics: parsed.lyrics && typeof parsed.lyrics === 'object' ? parsed.lyrics : {},
      favorites: Array.isArray(parsed.favorites) ? parsed.favorites : [],
      learned: Array.isArray(parsed.learned) ? parsed.learned : [],
    };
  }

  function readStoredState(key) {
    try {
      const raw = localStorage.getItem(key);
      return raw ? JSON.parse(raw) : null;
    } catch (error) {
      console.warn(`Cannot read lyricbook state: ${key}`, error);
      return null;
    }
  }

  function loadState() {
    const fallback = defaultState();
    const stored = readStoredState(STORAGE_KEY);
    if (stored) return normalizeState(stored, fallback);

    // A downloaded “含歌词离线 HTML” carries an embedded snapshot. It becomes
    // the initial state only until this particular copy is edited and saved.
    if (window.GEM_EMBEDDED_STATE && typeof window.GEM_EMBEDDED_STATE === 'object') {
      return normalizeState(window.GEM_EMBEDDED_STATE, fallback);
    }

    // Seamlessly carry over lyrics entered in the first edition.
    if (!window.GEM_EMBEDDED_ID) {
      const legacy = readStoredState(LEGACY_STORAGE_KEY);
      if (legacy) return normalizeState(legacy, fallback);
    }
    return fallback;
  }

  let state = loadState();
  let filteredSongs = [];
  let saveTimer = null;

  function saveState(message = '已保存到本机') {
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(state));
      if (message) {
        elements.saveStatus.textContent = message;
        window.clearTimeout(saveTimer);
        saveTimer = window.setTimeout(() => {
          elements.saveStatus.textContent = '仅保存在本机';
        }, 1400);
      }
    } catch (error) {
      console.warn('Cannot save lyricbook state', error);
      elements.saveStatus.textContent = '本机存储不可用';
    }
  }

  function currentSong() {
    return songs.find((song) => song.id === state.selectedId) || songs[0];
  }

  function lyricFor(song) {
    return String(state.lyrics[song.id] || '').trim();
  }

  function hasLyrics(song) {
    return lyricFor(song).length > 0;
  }

  function isFavorite(song) {
    return state.favorites.includes(song.id);
  }

  function isLearned(song) {
    return state.learned.includes(song.id);
  }

  function normalizeSearch(value) {
    return String(value || '')
      .normalize('NFKC')
      .toLocaleLowerCase('zh-CN')
      .replace(/[\s._·•'’“”"()（）\-—–/:：]/g, '');
  }

  function searchHaystack(song) {
    return normalizeSearch([song.title, ...(song.aliases || []), ...(song.tags || [])].join(' '));
  }

  function songMatchesFilter(song, filter) {
    switch (filter) {
      case '2026-main': return song.tags.includes('2026主歌单');
      case '2026-encore': return song.tags.includes('2026返场');
      case '2026-medley': return song.tags.includes('2026特别串烧');
      case 'live-extra': return song.tags.some((tag) => tag.includes('2026台北点歌') || tag.includes('2026台北特别片段'));
      case 'pending': return song.tags.some((tag) => tag.includes('待核实') || tag.includes('报批新增') || tag.includes('待官宣') || tag.includes('非正式曲名'));
      case 'filled': return hasLyrics(song);
      case 'empty': return !hasLyrics(song);
      case 'favorite': return isFavorite(song);
      case 'learned': return isLearned(song);
      case 'image1':
      case 'image2':
      case 'image3':
      case 'image4': return song.sources.includes(filter);
      default: return true;
    }
  }

  function statusRank(song) {
    if (song.tags.includes('2026主歌单')) return 0;
    if (song.tags.includes('2026特别串烧')) return 1;
    if (song.tags.some((tag) => tag.includes('2026台北点歌') || tag.includes('2026台北特别片段'))) return 2;
    if (song.tags.includes('2026返场')) return 3;
    if (song.tags.some((tag) => tag.includes('报批新增') || tag.includes('待官宣') || tag.includes('非正式曲名'))) return 4;
    return 5;
  }

  function getFilteredSongs() {
    const query = normalizeSearch(state.search);
    const result = songs.filter((song) => {
      if (!songMatchesFilter(song, state.filter)) return false;
      if (query && !searchHaystack(song).includes(query)) return false;
      return true;
    });

    return result.sort((a, b) => {
      if (state.sort === 'title') return a.title.localeCompare(b.title, 'zh-Hans-CN', { numeric: true, sensitivity: 'base' });
      if (state.sort === 'status') return statusRank(a) - statusRank(b) || a.title.localeCompare(b.title, 'zh-Hans-CN');
      if (state.sort === 'progress') return Number(hasLyrics(b)) - Number(hasLyrics(a)) || a.title.localeCompare(b.title, 'zh-Hans-CN');
      return Number(a.id.replace(/\D/g, '')) - Number(b.id.replace(/\D/g, ''));
    });
  }

  function descriptiveStatus(song) {
    if (song.tags.includes('2026主歌单')) return '2026 主歌单';
    if (song.tags.includes('2026特别串烧')) return '2026 特别串烧';
    if (song.tags.some((tag) => tag.includes('2026台北点歌'))) return '2026 台北点歌补充';
    if (song.tags.some((tag) => tag.includes('2026台北特别片段'))) return '2026 台北现场片段';
    if (song.tags.includes('2026返场')) return '2026 返场';
    if (song.tags.some((tag) => tag.includes('待官宣') || tag.includes('非正式曲名'))) return '待官宣占位';
    if (song.tags.some((tag) => tag.includes('报批新增'))) return '2026 报批新增';
    return song.sources.map((source) => sourceShort[source] || source).join(' · ');
  }

  function renderList() {
    filteredSongs = getFilteredSongs();
    elements.resultCount.textContent = `${filteredSongs.length} 首`;
    elements.songList.replaceChildren();

    if (!filteredSongs.length) {
      const empty = document.createElement('div');
      empty.className = 'sidebar-empty';
      empty.innerHTML = '<b>没有匹配曲目</b><br><small>换一个关键词或筛选条件试试。</small>';
      elements.songList.appendChild(empty);
      return;
    }

    const fragment = document.createDocumentFragment();
    filteredSongs.forEach((song, index) => {
      const button = document.createElement('button');
      button.type = 'button';
      button.className = `song-list-item${song.id === state.selectedId ? ' active' : ''}`;
      button.setAttribute('role', 'option');
      button.setAttribute('aria-selected', song.id === state.selectedId ? 'true' : 'false');
      button.dataset.songId = song.id;

      const number = document.createElement('span');
      number.className = 'song-list-number';
      number.textContent = String(index + 1).padStart(2, '0');

      const copy = document.createElement('span');
      copy.className = 'song-list-copy';
      const title = document.createElement('b');
      title.textContent = song.title;
      const meta = document.createElement('small');
      meta.textContent = descriptiveStatus(song);
      copy.append(title, meta);

      const status = document.createElement('span');
      status.className = 'song-list-status';
      if (isFavorite(song)) {
        const star = document.createElement('span');
        star.className = 'mini-star';
        star.textContent = '★';
        star.title = '已收藏';
        status.appendChild(star);
      }
      const dot = document.createElement('span');
      dot.className = `mini-dot${hasLyrics(song) ? ' filled' : ''}`;
      dot.title = hasLyrics(song) ? '已导入歌词' : '尚未导入歌词';
      status.appendChild(dot);

      button.append(number, copy, status);
      button.addEventListener('click', () => selectSong(song.id));
      fragment.appendChild(button);
    });
    elements.songList.appendChild(fragment);
  }

  function renderPreview(text) {
    elements.lyricPreview.replaceChildren();
    const stanzas = String(text || '').trim().split(/\n\s*\n/).filter(Boolean);
    const fragment = document.createDocumentFragment();
    stanzas.forEach((stanza) => {
      const div = document.createElement('div');
      div.className = 'stanza';
      div.textContent = stanza.trim();
      fragment.appendChild(div);
    });
    elements.lyricPreview.appendChild(fragment);
  }

  function renderDetail() {
    const song = currentSong();
    if (!song) return;
    const globalIndex = songs.findIndex((item) => item.id === song.id);
    const text = lyricFor(song);

    elements.songNumber.textContent = String(globalIndex + 1).padStart(2, '0');
    elements.songTotal.textContent = String(songs.length);
    elements.songKicker.textContent = descriptiveStatus(song);
    elements.songTitle.textContent = song.title;
    elements.songAliases.textContent = song.aliases?.length ? `原图别名 / 版本：${song.aliases.join(' · ')}` : '';

    elements.songTags.replaceChildren();
    (song.tags || []).forEach((tag) => {
      const span = document.createElement('span');
      span.className = 'tag-pill';
      span.textContent = tag;
      elements.songTags.appendChild(span);
    });

    if (song.note) {
      elements.songNote.hidden = false;
      elements.songNote.textContent = song.note;
    } else {
      elements.songNote.hidden = true;
      elements.songNote.textContent = '';
    }

    elements.lyricEditor.value = text;
    elements.charCount.textContent = `${text.length.toLocaleString('zh-CN')} 字`;
    const filled = Boolean(text);
    elements.emptyState.hidden = filled;
    elements.lyricPreview.hidden = !filled;
    if (filled) renderPreview(text);

    elements.favoriteButton.setAttribute('aria-pressed', isFavorite(song) ? 'true' : 'false');
    elements.learnedButton.setAttribute('aria-pressed', isLearned(song) ? 'true' : 'false');
    elements.learnedButton.textContent = isLearned(song) ? '✓ 已熟悉' : '标记为已熟悉';

    elements.sourcePills.replaceChildren();
    song.sources.forEach((source) => {
      const span = document.createElement('span');
      span.className = 'source-pill';
      span.textContent = sourceShort[source] || source;
      elements.sourcePills.appendChild(span);
    });

    elements.appleLink.href = song.links.apple_music_search;
    elements.youtubeLink.href = song.links.youtube_search;
    elements.officialLink.href = song.links.official_video_search;

    applyViewMode(state.viewMode);
    updateFocusContent();
    updateStats();
  }

  function updateStats() {
    const filled = songs.filter(hasLyrics).length;
    elements.statSongs.textContent = DATA.metadata.counts.unique_songs_excluding_other ?? songs.length;
    elements.statCoverage.textContent = DATA.metadata.counts.total_visible_entries ?? (DATA.metadata.counts.image1_entries + DATA.metadata.counts.image2_entries_including_other + DATA.metadata.counts.image3_entries + (DATA.metadata.counts.image4_entries || 0));
    elements.statFilled.textContent = filled;
    elements.statVerified.textContent = DATA.metadata.counts.new_entries_added_in_this_revision ?? DATA.metadata.counts.verified_2026_missing_from_original_three_images ?? 0;
  }

  function selectSong(id, options = {}) {
    if (!songs.some((song) => song.id === id)) return;
    state.selectedId = id;
    saveState('已切换');
    renderList();
    renderDetail();
    if (!options.keepSidebar) closeSidebar();
    if (options.scroll !== false && window.innerWidth < 992) {
      $('#readerCard').scrollIntoView({ behavior: 'smooth', block: 'start' });
    }
  }

  function navigate(delta) {
    const pool = filteredSongs.length ? filteredSongs : songs;
    let index = pool.findIndex((song) => song.id === state.selectedId);
    if (index < 0) index = 0;
    const next = pool[(index + delta + pool.length) % pool.length];
    selectSong(next.id, { scroll: false });
  }

  function applyViewMode(mode) {
    state.viewMode = mode === 'edit' ? 'edit' : 'preview';
    const editing = state.viewMode === 'edit';
    elements.previewTab.classList.toggle('active', !editing);
    elements.editTab.classList.toggle('active', editing);
    elements.previewTab.setAttribute('aria-selected', String(!editing));
    elements.editTab.setAttribute('aria-selected', String(editing));
    elements.previewPanel.hidden = editing;
    elements.editPanel.hidden = !editing;
    if (editing) requestAnimationFrame(() => elements.lyricEditor.focus({ preventScroll: true }));
    saveState('');
  }

  function updateLyrics(value) {
    const song = currentSong();
    if (!song) return;
    const normalized = String(value || '').replace(/\r\n/g, '\n');
    if (normalized.trim()) state.lyrics[song.id] = normalized;
    else delete state.lyrics[song.id];
    elements.charCount.textContent = `${normalized.trim().length.toLocaleString('zh-CN')} 字`;
    saveState('已自动保存');
    renderPreview(normalized);
    elements.emptyState.hidden = Boolean(normalized.trim());
    elements.lyricPreview.hidden = !normalized.trim();
    renderList();
    updateStats();
    updateFocusContent();
    updatePrintEstimate();
  }

  function toggleInArray(key, id) {
    const list = state[key];
    const index = list.indexOf(id);
    if (index >= 0) list.splice(index, 1);
    else list.push(id);
    saveState();
    renderList();
    renderDetail();
  }

  function openSidebar() {
    elements.sidebar.classList.add('open');
    elements.sidebarBackdrop.classList.add('open');
    elements.sidebarToggle.setAttribute('aria-expanded', 'true');
    document.body.style.overflow = 'hidden';
  }

  function closeSidebar() {
    elements.sidebar.classList.remove('open');
    elements.sidebarBackdrop.classList.remove('open');
    elements.sidebarToggle.setAttribute('aria-expanded', 'false');
    document.body.style.overflow = '';
  }

  function applyTheme(theme) {
    state.theme = theme === 'dark' ? 'dark' : 'light';
    elements.html.setAttribute('data-bs-theme', state.theme);
    document.querySelector('meta[name="theme-color"]')?.setAttribute('content', state.theme === 'dark' ? '#17121d' : '#6d28d9');
    saveState('');
  }

  function applyFontLevel(level) {
    const parsed = Math.max(0, Math.min(4, Number(level) || 0));
    state.fontLevel = parsed;
    elements.fontRange.value = String(parsed);
    document.documentElement.style.setProperty('--reading-scale', String(fontScales[parsed]));
    saveState('');
  }

  function updateFocusContent() {
    const song = currentSong();
    if (!song) return;
    elements.focusKicker.textContent = descriptiveStatus(song);
    elements.focusTitle.textContent = song.title;
    elements.focusLyrics.textContent = lyricFor(song) || '尚未导入歌词。';
  }

  function openFocus() {
    updateFocusContent();
    elements.focusOverlay.hidden = false;
    document.body.style.overflow = 'hidden';
    elements.exitFocus.focus();
  }

  function closeFocus() {
    elements.focusOverlay.hidden = true;
    document.body.style.overflow = '';
    elements.focusButton.focus();
  }

  function showToast(message) {
    const toast = document.createElement('div');
    toast.className = 'app-toast';
    toast.textContent = message;
    elements.toastRegion.appendChild(toast);
    window.setTimeout(() => {
      toast.style.opacity = '0';
      toast.style.transform = 'translateY(6px)';
      window.setTimeout(() => toast.remove(), 220);
    }, 2600);
  }

  function safeFilename(value) {
    return value.replace(/[\\/:*?"<>|]/g, '_').replace(/\s+/g, '_');
  }

  function downloadBlob(content, type, filename) {
    const blob = new Blob([content], { type });
    const url = URL.createObjectURL(blob);
    const anchor = document.createElement('a');
    anchor.href = url;
    anchor.download = filename;
    document.body.appendChild(anchor);
    anchor.click();
    anchor.remove();
    window.setTimeout(() => URL.revokeObjectURL(url), 1000);
  }

  function exportBackup() {
    const payload = {
      format: 'gem-lyricbook-backup-v2',
      exportedAt: new Date().toISOString(),
      state: {
        lyrics: state.lyrics,
        favorites: state.favorites,
        learned: state.learned,
      },
      titles: Object.fromEntries(songs.map((song) => [song.id, song.title])),
    };
    downloadBlob(JSON.stringify(payload, null, 2), 'application/json;charset=utf-8', `GEM歌词本备份_${new Date().toISOString().slice(0, 10)}.json`);
    showToast('JSON 备份已导出');
  }

  function exportMarkdown() {
    const blocks = ['# G.E.M. I AM GLORIA 私人歌词本', '', '> 由本地歌词本导出。', ''];
    songs.forEach((song) => {
      const text = lyricFor(song);
      if (!text) return;
      blocks.push(`## ${song.title}`, '', text, '');
    });
    if (blocks.length === 4) blocks.push('尚未导入任何歌词。');
    downloadBlob(blocks.join('\n'), 'text/markdown;charset=utf-8', `GEM歌词本_${new Date().toISOString().slice(0, 10)}.md`);
    showToast('Markdown 已导出');
  }


  function scriptSafeJson(value) {
    return JSON.stringify(value)
      .replace(/</g, '\\u003c')
      .replace(/>/g, '\\u003e')
      .replace(/&/g, '\\u0026')
      .replace(/\u2028/g, '\\u2028')
      .replace(/\u2029/g, '\\u2029');
  }

  function newEmbeddedId() {
    if (window.crypto?.randomUUID) return window.crypto.randomUUID();
    return `${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 10)}`;
  }

  function exportStandaloneHtml() {
    if (!window.GEM_SINGLE_FILE) {
      showToast('请在“单文件版 HTML”中使用此功能');
      return;
    }

    try {
      const clone = document.documentElement.cloneNode(true);
      const body = clone.querySelector('body');
      body?.classList.remove('modal-open');
      if (body) {
        body.style.removeProperty('overflow');
        body.style.removeProperty('padding-right');
      }
      clone.querySelectorAll('.modal-backdrop, .app-toast').forEach((node) => node.remove());
      clone.querySelectorAll('.modal.show').forEach((modal) => {
        modal.classList.remove('show');
        modal.style.display = 'none';
        modal.setAttribute('aria-hidden', 'true');
        modal.removeAttribute('aria-modal');
        modal.removeAttribute('role');
      });
      clone.querySelector('#songSidebar')?.classList.remove('open');
      clone.querySelector('#sidebarBackdrop')?.classList.remove('open');
      clone.querySelector('#focusOverlay')?.setAttribute('hidden', '');
      const printRoot = clone.querySelector('#printRoot');
      if (printRoot) {
        printRoot.innerHTML = '';
        printRoot.setAttribute('aria-hidden', 'true');
      }
      const dynamicPrintStyle = clone.querySelector('#dynamicPrintStyle');
      if (dynamicPrintStyle) dynamicPrintStyle.textContent = '';
      clone.querySelector('#gem-embedded-state')?.remove();

      const appScript = clone.querySelector('#gem-app');
      if (!appScript?.parentNode) throw new Error('未找到内嵌程序入口');
      const embeddedState = document.createElement('script');
      embeddedState.id = 'gem-embedded-state';
      embeddedState.textContent = `window.GEM_EMBEDDED_ID=${scriptSafeJson(newEmbeddedId())};window.GEM_EMBEDDED_STATE=${scriptSafeJson({ ...state, exportedAt: new Date().toISOString() })};`;
      appScript.parentNode.insertBefore(embeddedState, appScript);

      const html = `<!doctype html>\n${clone.outerHTML}`;
      const filledCount = songs.filter(hasLyrics).length;
      downloadBlob(html, 'text/html;charset=utf-8', `GEM歌词本_含歌词_${new Date().toISOString().slice(0, 10)}.html`);
      showToast(`已导出离线 HTML（含 ${filledCount} 首歌词）`);
    } catch (error) {
      console.error('Cannot export standalone HTML', error);
      showToast(`离线 HTML 导出失败：${error.message}`);
    }
  }

  function exportTemplate() {
    const blocks = ['# G.E.M. 歌词批量导入模板', '', '> 请仅粘贴你有权使用的歌词。网页支持识别 `## 歌名` 标题块。', ''];
    songs.forEach((song) => blocks.push(`## ${song.title}`, '', '[在此粘贴歌词]', ''));
    downloadBlob(blocks.join('\n'), 'text/markdown;charset=utf-8', 'GEM歌词批量导入模板.md');
    showToast('空白导入模板已生成');
  }

  function buildAliasMap() {
    const map = new Map();
    const add = (key, song) => {
      const normalized = normalizeSearch(key);
      if (normalized) map.set(normalized, song);
    };
    songs.forEach((song) => {
      add(song.title, song);
      (song.aliases || []).forEach((alias) => add(alias, song));
    });
    const manual = {
      allaboutyou: 'All About U',
      allaboutu: 'All About U',
      findyou: 'FIND YOU',
      walkonwater: 'Walk On Water',
      whathaveyoudone: 'WHAT HAVE U DONE',
      whathaveudone: 'WHAT HAVE U DONE',
      hell坠落天堂: 'HELL',
      'ainy爱你': 'A.I.N.Y.',
    };
    Object.entries(manual).forEach(([alias, title]) => {
      const song = songs.find((item) => item.title === title);
      if (song) add(alias, song);
    });
    return map;
  }

  const aliasMap = buildAliasMap();

  function matchTitle(title) {
    const normalized = normalizeSearch(title);
    if (aliasMap.has(normalized)) return aliasMap.get(normalized);
    // Conservative fuzzy fallback: only accept a unique containment match.
    const candidates = songs.filter((song) => {
      const canonical = normalizeSearch(song.title);
      return normalized.length >= 3 && (canonical.includes(normalized) || normalized.includes(canonical));
    });
    return candidates.length === 1 ? candidates[0] : null;
  }

  function parseMarkdown(text) {
    const normalized = String(text || '').replace(/\r\n/g, '\n');
    const headingRegex = /^##\s+(.+?)\s*$/gm;
    const matches = Array.from(normalized.matchAll(headingRegex));
    const entries = [];
    matches.forEach((match, index) => {
      const start = match.index + match[0].length;
      const end = index + 1 < matches.length ? matches[index + 1].index : normalized.length;
      const title = match[1].trim();
      const lyrics = normalized.slice(start, end).trim().replace(/^\[在此粘贴歌词\]$/m, '').trim();
      entries.push({ title, lyrics });
    });
    return entries;
  }

  function importEntries(entries, resultElement = elements.importResult) {
    let matched = 0;
    let skippedEmpty = 0;
    const unmatched = [];
    entries.forEach(({ title, lyrics }) => {
      const song = matchTitle(title);
      if (!song) {
        unmatched.push(title);
        return;
      }
      if (!String(lyrics || '').trim()) {
        skippedEmpty += 1;
        return;
      }
      state.lyrics[song.id] = String(lyrics).replace(/\r\n/g, '\n').trim();
      matched += 1;
    });
    saveState('导入完成');
    renderList();
    renderDetail();
    updatePrintEstimate();
    const summary = [`成功导入 ${matched} 首。`];
    if (skippedEmpty) summary.push(`跳过 ${skippedEmpty} 个空白标题块。`);
    if (unmatched.length) summary.push(`未匹配 ${unmatched.length} 项：${unmatched.slice(0, 12).join('、')}${unmatched.length > 12 ? '…' : ''}`);
    resultElement.textContent = summary.join('\n');
    showToast(`已导入 ${matched} 首歌词`);
  }

  function parseJsonImport(text) {
    const parsed = JSON.parse(text);
    const entries = [];
    if (['gem-lyricbook-backup-v1', 'gem-lyricbook-backup-v2'].includes(parsed?.format) && parsed.state?.lyrics) {
      Object.entries(parsed.state.lyrics).forEach(([id, lyrics]) => {
        const title = parsed.titles?.[id] || songs.find((song) => song.id === id)?.title;
        if (title) entries.push({ title, lyrics });
      });
      if (Array.isArray(parsed.state.favorites)) state.favorites = parsed.state.favorites.filter((id) => songs.some((song) => song.id === id));
      if (Array.isArray(parsed.state.learned)) state.learned = parsed.state.learned.filter((id) => songs.some((song) => song.id === id));
      return entries;
    }
    if (parsed?.lyrics && typeof parsed.lyrics === 'object') {
      Object.entries(parsed.lyrics).forEach(([title, lyrics]) => entries.push({ title, lyrics }));
      return entries;
    }
    if (Array.isArray(parsed)) {
      parsed.forEach((item) => {
        if (item && item.title) entries.push({ title: item.title, lyrics: item.lyrics || '' });
      });
      return entries;
    }
    throw new Error('JSON 结构不受支持');
  }

  async function importFile() {
    const file = elements.importFile.files?.[0];
    if (!file) {
      elements.importResult.textContent = '请先选择 JSON、Markdown 或 TXT 文件。';
      return;
    }
    try {
      const text = await file.text();
      const entries = file.name.toLocaleLowerCase().endsWith('.json') ? parseJsonImport(text) : parseMarkdown(text);
      if (!entries.length) throw new Error('没有识别到 “## 歌名” 标题块');
      importEntries(entries);
    } catch (error) {
      elements.importResult.textContent = `导入失败：${error.message}`;
    }
  }

  function renderCoverage() {
    ['image1', 'image2', 'image3', 'image4'].forEach((source, idx) => {
      const target = $(`#coverageImage${idx + 1}`);
      target.replaceChildren();
      const fragment = document.createDocumentFragment();
      DATA.coverage[source].forEach((entry) => {
        const item = document.createElement('div');
        item.className = 'coverage-item';
        const number = document.createElement('span');
        number.className = 'number';
        number.textContent = entry.position;
        const copy = document.createElement('div');
        const raw = document.createElement('div');
        raw.className = 'raw';
        raw.textContent = entry.raw;
        const canonical = document.createElement('div');
        canonical.className = 'canonical';
        canonical.textContent = entry.raw === entry.canonical ? '已收录' : `归一为：${entry.canonical}`;
        copy.append(raw, canonical);
        item.append(number, copy);
        fragment.appendChild(item);
      });
      target.appendChild(fragment);
    });
  }

  function renderSources() {
    const target = $('#sourceList');
    target.replaceChildren();
    DATA.metadata.sources.forEach((source) => {
      const entry = document.createElement('div');
      entry.className = 'source-entry';
      const link = document.createElement('a');
      link.href = source.url;
      link.target = '_blank';
      link.rel = 'noopener';
      link.textContent = source.label;
      const url = document.createElement('small');
      url.textContent = source.url;
      entry.append(link, url);
      target.appendChild(entry);
    });
  }

  function escapeHTML(value) {
    return String(value ?? '')
      .replace(/&/g, '&amp;')
      .replace(/</g, '&lt;')
      .replace(/>/g, '&gt;')
      .replace(/"/g, '&quot;')
      .replace(/'/g, '&#039;');
  }

  function splitLongText(text, limit) {
    const clean = String(text || '').trim().replace(/\r\n/g, '\n');
    if (!clean) return [''];
    const paragraphs = clean.split(/\n\s*\n/).map((p) => p.trim()).filter(Boolean);
    const atomic = [];

    paragraphs.forEach((paragraph) => {
      if (paragraph.length <= limit) {
        atomic.push(paragraph);
        return;
      }
      const lines = paragraph.split('\n').filter((line) => line.trim());
      let buffer = '';
      lines.forEach((line) => {
        if ((buffer + '\n' + line).trim().length > limit && buffer) {
          atomic.push(buffer.trim());
          buffer = '';
        }
        if (line.length > limit) {
          if (buffer) {
            atomic.push(buffer.trim());
            buffer = '';
          }
          for (let i = 0; i < line.length; i += limit) atomic.push(line.slice(i, i + limit));
        } else {
          buffer += `${buffer ? '\n' : ''}${line}`;
        }
      });
      if (buffer) atomic.push(buffer.trim());
    });

    const pages = [];
    let page = '';
    atomic.forEach((paragraph) => {
      const candidate = page ? `${page}\n\n${paragraph}` : paragraph;
      if (candidate.length > limit && page) {
        pages.push(page);
        page = paragraph;
      } else {
        page = candidate;
      }
    });
    if (page) pages.push(page);
    return pages.length ? pages : [''];
  }

  function printSelection() {
    const scope = $('input[name="printScope"]:checked')?.value || 'filtered';
    if (scope === 'current') return [currentSong()].filter(Boolean);
    if (scope === 'all') return [...songs];
    return filteredSongs.length ? [...filteredSongs] : [...songs];
  }

  function printSettings() {
    return {
      size: $('input[name="printSize"]:checked')?.value || 'a4',
      scope: $('input[name="printScope"]:checked')?.value || 'filtered',
      cover: elements.printCover.checked,
      toc: elements.printToc.checked,
      includeEmpty: elements.printEmpty.checked,
      notes: elements.printNotes.checked,
    };
  }

  function estimateLogicalPages(selection, settings) {
    const size = settings.size === 'a4' ? 'a4' : 'a5';
    const limit = size === 'a4' ? 2200 : 1180;
    let count = settings.cover ? 1 : 0;
    const printable = selection.filter((song) => settings.includeEmpty || hasLyrics(song));
    if (settings.toc && printable.length) count += Math.max(1, Math.ceil(printable.length / (size === 'a4' ? 40 : 23)));
    printable.forEach((song) => {
      count += hasLyrics(song) ? splitLongText(lyricFor(song), limit).length : 1;
    });
    count += 1; // colophon
    return { count, printable };
  }

  function updatePrintEstimate() {
    const settings = printSettings();
    const selection = printSelection();
    const { count, printable } = estimateLogicalPages(selection, settings);
    if (!printable.length) {
      elements.printEstimate.textContent = '当前设置没有可输出歌曲；请勾选“包含尚未导入歌词的曲目”或先导入歌词。';
      return;
    }
    if (settings.size === 'booklet') {
      const padded = Math.ceil(count / 4) * 4;
      elements.printEstimate.textContent = `预计 ${printable.length} 首，约 ${padded} 个 A5 逻辑页，拼成 ${padded / 4} 张双面 A4 纸。`;
    } else {
      elements.printEstimate.textContent = `预计 ${printable.length} 首，约 ${count} 页 ${settings.size.toUpperCase()}。实际页数会随歌词长度变化。`;
    }
  }

  function pageShell(content, classes = '', pageNumber = '') {
    return `<section class="print-page ${classes}"><div class="print-page-inner">${content}</div>${pageNumber ? `<div class="print-page-number">${escapeHTML(pageNumber)}</div>` : ''}</section>`;
  }

  function coverPage(settings) {
    const subtitle = settings.size === 'booklet' ? 'A4 对折小册打印版' : `${settings.size.toUpperCase()} 打印版`;
    return `<section class="print-page print-cover"><div class="print-cover-content"><div class="print-cover-mark">G</div><h1>I AM GLORIA<br>私人歌词本</h1><p>完整曲目核对 · 授权歌词本地导入 · 多端阅读与印刷排版</p><div class="print-cover-meta">${escapeHTML(subtitle)} · 2026-08-30 四图修订</div></div></section>`;
  }

  function colophonPage(pageNumber) {
    return pageShell(`<div class="print-colophon"><h2>关于这本歌词本</h2><p>本版完整保留四张截图中的所有可见曲目条目，并补入已核实的 2026 现场遗漏项目。为尊重版权，完整歌词仅来自使用者自行导入且有权使用的文本；未导入页面显示为空白模板。</p><p>打印建议：彩色、实际尺寸 100%。A4 对折版请先以 4 页测试双面翻转方向。</p></div>`, 'print-colophon', pageNumber);
  }

  function songPage(song, chunk, chunkIndex, chunkTotal, pageNumber, settings) {
    const aliases = song.aliases?.length ? `版本 / 别名：${song.aliases.join(' · ')}` : '';
    const tags = (song.tags || []).map((tag) => `<span class="print-tag">${escapeHTML(tag)}</span>`).join('');
    const continuation = chunkTotal > 1 ? ` · ${chunkIndex + 1}/${chunkTotal}` : '';
    const note = settings.notes && song.note ? `<div class="print-note">${escapeHTML(song.note)}</div>` : '';
    const body = chunk
      ? `<div class="print-lyrics">${escapeHTML(chunk)}</div>`
      : `<div class="print-placeholder"><div><b>歌词尚未导入</b><br>请在电子版中粘贴你有权使用的歌词后重新生成 PDF。</div></div>`;
    return pageShell(`
      <div class="print-running-head"><span>G.E.M. · I AM GLORIA</span><span>${escapeHTML(descriptiveStatus(song))}</span></div>
      <h2 class="print-song-title">${escapeHTML(song.title)}${continuation}</h2>
      ${aliases ? `<div class="print-song-subtitle">${escapeHTML(aliases)}</div>` : ''}
      ${tags ? `<div class="print-tags">${tags}</div>` : ''}
      ${note}
      ${body}
    `, 'print-song-page', pageNumber);
  }

  function buildLogicalPages(selection, settings) {
    const targetSize = settings.size === 'a4' ? 'a4' : 'a5';
    const limit = targetSize === 'a4' ? 2200 : 1180;
    const printable = selection.filter((song) => settings.includeEmpty || hasLyrics(song));
    const songChunks = printable.map((song) => ({ song, chunks: hasLyrics(song) ? splitLongText(lyricFor(song), limit) : [''] }));
    const tocPerPage = targetSize === 'a4' ? 40 : 23;
    const tocPageCount = settings.toc && printable.length ? Math.max(1, Math.ceil(printable.length / tocPerPage)) : 0;
    const coverCount = settings.cover ? 1 : 0;

    let nextSongPage = coverCount + tocPageCount + 1;
    const tocEntries = [];
    songChunks.forEach(({ song, chunks }) => {
      tocEntries.push({ song, page: nextSongPage });
      nextSongPage += chunks.length;
    });

    const pages = [];
    if (settings.cover) pages.push(coverPage(settings));

    if (settings.toc && tocEntries.length) {
      for (let i = 0; i < tocEntries.length; i += tocPerPage) {
        const batch = tocEntries.slice(i, i + tocPerPage);
        const entries = batch.map((entry, idx) => {
          const number = i + idx + 1;
          return `<div class="print-toc-entry"><span class="toc-num">${String(number).padStart(2, '0')}</span><span>${escapeHTML(entry.song.title)}</span><span class="toc-page">${entry.page}</span></div>`;
        }).join('');
        const pageNo = pages.length + 1;
        pages.push(pageShell(`<div class="print-running-head"><span>G.E.M. · I AM GLORIA</span><span>曲目目录</span></div><h2 class="print-toc-title">目录</h2><div class="print-toc-grid">${entries}</div>`, 'print-toc-page', pageNo));
      }
    }

    songChunks.forEach(({ song, chunks }) => {
      chunks.forEach((chunk, index) => {
        const pageNo = pages.length + 1;
        pages.push(songPage(song, chunk, index, chunks.length, pageNo, settings));
      });
    });

    pages.push(colophonPage(pages.length + 1));
    return { pages, printable };
  }

  function imposeBooklet(logicalPages) {
    const pages = [...logicalPages];
    while (pages.length % 4 !== 0) pages.push('<section class="print-page blank-logical-page"><div class="print-page-inner"></div></section>');
    const total = pages.length;
    const sheets = [];
    for (let sheet = 0; sheet < total / 4; sheet += 1) {
      const frontLeft = total - 1 - 2 * sheet;
      const frontRight = 2 * sheet;
      const backLeft = 1 + 2 * sheet;
      const backRight = total - 2 - 2 * sheet;
      sheets.push(`<section class="booklet-sheet booklet-front"><div class="booklet-half">${pages[frontLeft]}</div><div class="booklet-half">${pages[frontRight]}</div></section>`);
      sheets.push(`<section class="booklet-sheet booklet-back"><div class="booklet-half">${pages[backLeft]}</div><div class="booklet-half">${pages[backRight]}</div></section>`);
    }
    return sheets.join('');
  }

  function preparePrint() {
    const settings = printSettings();
    const selection = printSelection();
    const { pages, printable } = buildLogicalPages(selection, settings);
    if (!printable.length) {
      showToast('没有可输出曲目：请导入歌词或勾选空白曲目');
      return;
    }

    elements.printRoot.innerHTML = settings.size === 'booklet' ? imposeBooklet(pages) : pages.join('');
    elements.printRoot.setAttribute('aria-hidden', 'false');
    elements.dynamicPrintStyle.textContent = settings.size === 'booklet'
      ? '@page { size: A4 landscape; margin: 0; } * { -webkit-print-color-adjust: exact !important; print-color-adjust: exact !important; }'
      : `@page { size: ${settings.size.toUpperCase()} portrait; margin: 0; } * { -webkit-print-color-adjust: exact !important; print-color-adjust: exact !important; }`;

    const modalElement = $('#printModal');
    const modal = window.bootstrap?.Modal.getInstance(modalElement);
    if (modal) modal.hide();

    window.setTimeout(() => window.print(), 320);
  }

  function cleanupPrint() {
    elements.printRoot.innerHTML = '';
    elements.printRoot.setAttribute('aria-hidden', 'true');
    elements.dynamicPrintStyle.textContent = '';
  }

  function bindEvents() {
    elements.search.addEventListener('input', (event) => {
      state.search = event.target.value;
      saveState('');
      renderList();
      updatePrintEstimate();
    });
    elements.filter.addEventListener('change', (event) => {
      state.filter = event.target.value;
      saveState('');
      renderList();
      updatePrintEstimate();
    });
    elements.sort.addEventListener('change', (event) => {
      state.sort = event.target.value;
      saveState('');
      renderList();
      updatePrintEstimate();
    });
    elements.fontRange.addEventListener('input', (event) => applyFontLevel(event.target.value));
    elements.previewTab.addEventListener('click', () => applyViewMode('preview'));
    elements.editTab.addEventListener('click', () => applyViewMode('edit'));
    elements.startEditing.addEventListener('click', () => applyViewMode('edit'));
    elements.lyricEditor.addEventListener('input', (event) => updateLyrics(event.target.value));
    elements.clearLyrics.addEventListener('click', () => {
      const song = currentSong();
      if (!song || !hasLyrics(song)) return;
      if (!window.confirm(`确定清空《${song.title}》的本地歌词吗？`)) return;
      elements.lyricEditor.value = '';
      updateLyrics('');
    });
    elements.favoriteButton.addEventListener('click', () => toggleInArray('favorites', currentSong().id));
    elements.learnedButton.addEventListener('click', () => toggleInArray('learned', currentSong().id));
    elements.previousSong.addEventListener('click', () => navigate(-1));
    elements.nextSong.addEventListener('click', () => navigate(1));
    elements.sidebarToggle.addEventListener('click', openSidebar);
    elements.sidebarClose.addEventListener('click', closeSidebar);
    elements.sidebarBackdrop.addEventListener('click', closeSidebar);
    elements.themeButton.addEventListener('click', () => applyTheme(state.theme === 'dark' ? 'light' : 'dark'));
    elements.focusButton.addEventListener('click', openFocus);
    elements.exitFocus.addEventListener('click', closeFocus);
    elements.focusOverlay.addEventListener('click', (event) => {
      if (event.target === elements.focusOverlay) closeFocus();
    });
    elements.importButton.addEventListener('click', importFile);
    elements.pasteImportButton.addEventListener('click', () => {
      const entries = parseMarkdown(elements.bulkPaste.value);
      if (!entries.length) {
        elements.importResult.textContent = '没有识别到 “## 歌名” 标题块。';
        return;
      }
      importEntries(entries);
    });
    elements.exportHtml?.addEventListener('click', exportStandaloneHtml);
    elements.exportJson.addEventListener('click', exportBackup);
    elements.exportMarkdown.addEventListener('click', exportMarkdown);
    elements.downloadTemplate.addEventListener('click', exportTemplate);
    elements.printBuildButton.addEventListener('click', preparePrint);
    $$('input[name="printSize"], input[name="printScope"], #printCover, #printToc, #printEmpty, #printNotes').forEach((input) => input.addEventListener('change', updatePrintEstimate));
    $('#printModal').addEventListener('show.bs.modal', updatePrintEstimate);
    window.addEventListener('afterprint', cleanupPrint);
    window.addEventListener('resize', () => { if (window.innerWidth >= 992) closeSidebar(); });

    document.addEventListener('keydown', (event) => {
      const tag = document.activeElement?.tagName;
      const editingText = tag === 'TEXTAREA' || tag === 'INPUT' || document.activeElement?.isContentEditable;
      if ((event.metaKey || event.ctrlKey) && event.key.toLocaleLowerCase() === 'k') {
        event.preventDefault();
        elements.search.focus();
        elements.search.select();
        return;
      }
      if (event.key === 'Escape') {
        if (!elements.focusOverlay.hidden) closeFocus();
        else closeSidebar();
        return;
      }
      if (!editingText && event.key === 'ArrowLeft') navigate(-1);
      if (!editingText && event.key === 'ArrowRight') navigate(1);
    });
  }

  function initialize() {
    if (!songs.some((song) => song.id === state.selectedId)) state.selectedId = songs[0]?.id || '';
    elements.search.value = state.search || '';
    elements.filter.value = state.filter || 'all';
    elements.sort.value = state.sort || 'source';
    // Defaults may be invalid after future app versions.
    if (elements.filter.selectedIndex < 0) elements.filter.value = state.filter = 'all';
    if (elements.sort.selectedIndex < 0) elements.sort.value = state.sort = 'source';
    applyTheme(state.theme);
    applyFontLevel(state.fontLevel);
    renderCoverage();
    renderSources();
    renderList();
    renderDetail();
    bindEvents();
    updatePrintEstimate();

    if (elements.exportHtml && !window.GEM_SINGLE_FILE) {
      elements.exportHtml.disabled = true;
      elements.exportHtml.title = '请打开随项目提供的单文件版 HTML 后再导出';
    }

    if (!window.GEM_SINGLE_FILE && 'serviceWorker' in navigator && /^https?:$/.test(location.protocol)) {
      navigator.serviceWorker.register('./sw.js').catch((error) => console.warn('Service worker registration failed', error));
    }
  }

  initialize();
})();
