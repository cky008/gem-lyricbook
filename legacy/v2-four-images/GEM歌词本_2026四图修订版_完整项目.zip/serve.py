#!/usr/bin/env python3
"""Run the lyricbook locally so PWA/offline installation works."""
from http.server import ThreadingHTTPServer, SimpleHTTPRequestHandler
from pathlib import Path
import os

root = Path(__file__).resolve().parent
os.chdir(root)
address = ('127.0.0.1', 8000)
print(f'Open http://{address[0]}:{address[1]}/index.html')
ThreadingHTTPServer(address, SimpleHTTPRequestHandler).serve_forever()
